// 服务器和某个客户端的通讯线程

package modal;

import common.*;

import java.net.*;
import java.io.*;
import java.util.HashMap;

public class MyThread extends Thread{

    Socket socket;
    public static HashMap sockets = new HashMap<String,MyThread>();
    ObjectInputStream objectInputStream;
    ObjectOutputStream objectOutputStream;
    User user;


    public MyThread(Socket s) {
        // 把服务器与该客户端的连接赋给socket
        this.socket = s;
        try {
            objectInputStream = new ObjectInputStream(socket.getInputStream());
            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        }catch (Exception e){
            e.printStackTrace();
        }
        user = new User();
    }

    public void run() {
        try {
            while (true) {
                user = (User) objectInputStream.readObject();

                System.out.println(user.toString());
                // 验证用户信息是否正确，并返回响应数据
                Message res = new Message();
                if (user.getPassword().equals("1")) {       //登陆成功
                    res.setCode("1");
                    objectOutputStream.writeObject(res);

                    sockets.put(user.getUsername(), this);
                    break;
                } else {    // 登陆失败，关闭连接
                    res.setCode("2");
                    objectOutputStream.writeObject(res);
                }
            }

        System.out.println(user.getUsername() + "登入成功");
        Message msg = new Message();

        while (true) {
            // 接收客户端的信息
            System.out.println("in");
            msg = (Message) objectInputStream.readObject();


                // 获得getter的线程
            MyThread getterThread = (MyThread) sockets.get(msg.getGetter());
            if (getterThread==null){
                msg.setCode("2");
                msg.setMsg("用户不在线");
                objectOutputStream.writeObject(msg);
                objectOutputStream.reset();
            }
            else {
                System.out.println(msg.getSender() + "给" + msg.getGetter() + "发消息：" + msg.getMsg());
                msg.setCode("1");
                System.out.println(getterThread.user.toString());
                getterThread.objectOutputStream.reset();
                getterThread.objectOutputStream.writeObject(msg);
            }
        }
    }catch (Exception e){
            e.printStackTrace();
        }
}
}
