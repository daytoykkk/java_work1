// 服务器，监听客户端发送的请求

package modal;

import common.*;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;

public class MyServer {

    public MyServer() {
        try {
            System.out.println("服务器端口号：8888正在监听...");
            ServerSocket ss = new ServerSocket(8888);
            while(true) {
                // 等待连接
                Socket socket = ss.accept();
                // 接收客户端发来的信息
                MyThread myThread = new MyThread(socket);
                myThread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
