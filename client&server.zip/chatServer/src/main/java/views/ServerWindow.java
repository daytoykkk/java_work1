// 聊天界面
// 实现启动、关闭服务器

package views;

import modal.MyServer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ServerWindow extends JFrame implements ActionListener{

    JPanel box;
    JButton startBtn, closeBtn;

    public ServerWindow() {
        box = new JPanel();
        startBtn = new JButton("启动服务器");
        closeBtn = new JButton("关闭服务器");
        box.add(startBtn);
        box.add(closeBtn);

        // 按钮点击事件
        startBtn.addActionListener(this);

        this.add(box);
        this.setSize(500,400);
        this.setTitle("服务器端");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public static void main(String[] args) {
        ServerWindow test = new ServerWindow();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == startBtn) {
            new MyServer();
        }
    }
}
