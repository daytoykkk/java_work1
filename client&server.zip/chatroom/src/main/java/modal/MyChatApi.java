// 客户端连接服务器

package modal;

import common.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.net.*;
import java.io.*;


public class MyChatApi {
    private  Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;


    public MyChatApi (Socket socket,ObjectOutputStream outputStream,ObjectInputStream inputStream){
        this.socket = socket;
        this.outputStream = outputStream;
        this.inputStream = inputStream;
    }

    // 第一次登陆请求
    public boolean sendLoginInfo(User u) {
        boolean flag = false;
        try {
            // 发送请求
            outputStream.writeObject(u);
            // 接收响应数据
            Message data = (Message) inputStream.readObject();
            System.out.println(data.toString());
            if(data.getCode().equals("1")) {
                // 登陆成功
                flag = true;
            } else {
                flag = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
        return flag;
    }

    public void sendInfoToServer (Object info) {
        try {
            Socket socket = new Socket("127.0.0.1",8888);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }
    }
}
