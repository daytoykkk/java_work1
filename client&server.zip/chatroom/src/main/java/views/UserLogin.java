//用户登陆界面

package views;

import common.*;
import modal.MyChatApi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class UserLogin extends JFrame implements ActionListener{

    Socket socket;
    JLabel header;
    JTabbedPane menu;
    JPanel loginBox, regBox;
    JLabel loginNameLabel, loginPassLabel, regNameLabel, regPassLabel;
    JTextField loginNameInput, regNameInput;
    JPasswordField loginPassInput, regPassInput;
    JButton loginBtn, regBtn, cancelBtn1, cancelBtn2;
    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;

    public UserLogin() {
        try {
            socket = new Socket("127.0.0.1",8888);
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 头部
        header = new JLabel(new ImageIcon("image/background.JPG"));

        // 按钮
        loginBtn = new JButton("登陆");
        regBtn = new JButton("注册");
        cancelBtn1 = new JButton("取消");
        cancelBtn2 = new JButton("取消");

        // 按钮点击事件
        loginBtn.addActionListener(this);

        // 标签页，分登陆和注册
        menu  =new JTabbedPane();
        loginBox = new JPanel(new GridLayout(3,2,4,4));
        regBox = new JPanel(new GridLayout(3,2,4,4));
        loginNameLabel = new JLabel("用户名：", JLabel.CENTER);
        regNameLabel = new JLabel("用户名：", JLabel.CENTER);
        loginPassLabel = new JLabel("密码：", JLabel.CENTER);
        regPassLabel = new JLabel("密码：", JLabel.CENTER);
        loginNameInput = new JTextField();
        loginNameInput.setPreferredSize(new Dimension (50,20));
        regNameInput = new JTextField();
        loginPassInput = new JPasswordField();
        regPassInput = new JPasswordField();
        loginBox.add(loginNameLabel);
        loginBox.add(loginNameInput);
        loginBox.add(loginPassLabel);
        loginBox.add(loginPassInput);
        loginBox.add(loginBtn);
        loginBox.add(cancelBtn1);
        regBox.add(regNameLabel);
        regBox.add(regNameInput);
        regBox.add(regPassLabel);
        regBox.add(regPassInput);
        regBox.add(regBtn);
        regBox.add(cancelBtn2);
        menu.addTab("登陆", loginBox);
        menu.addTab("注册", regBox);

        // 窗口设置
        this.add(header, "North");
        this.add(menu);
        this.setSize(500,400);
        this.setTitle("用户登录");
        this.setIconImage((new ImageIcon("image/logo.JPEG")).getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // 登陆
        if(e.getSource() == loginBtn) {
            User user = new User();
            user.setUsername(loginNameInput.getText().trim());
            user.setPassword(new String(loginPassInput.getPassword()));
            System.out.println(user.toString());
            MyChatApi myChatApi = new MyChatApi(socket,outputStream,inputStream);
            boolean isLegal = myChatApi.sendLoginInfo(user);
            if(isLegal) {   // 登陆成功，跳转好友列表页面
                new FriendList(user.getUsername(),socket,outputStream,inputStream);
                // 关闭登陆界面
                this.dispose();
            } else {    // 登陆失败，弹窗提示
                JOptionPane.showMessageDialog(this,"用户名密码错误！");
            }
        }
    }
}
