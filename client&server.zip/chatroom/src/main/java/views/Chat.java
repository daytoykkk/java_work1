// 聊天窗口
package views;

import common.Message;
import modal.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Chat extends JFrame implements ActionListener,Runnable{
    private String myId, friendId;

    JPanel sendBox;
    JTextArea dialogBox;
    JTextField input;
    JButton btn;
    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;
    Socket socket;

    public Chat(String myId, String friendId, Socket socket, ObjectInputStream inputStream, ObjectOutputStream outputStream) {
        this.socket = socket;
        this.outputStream = outputStream;
        this.inputStream = inputStream;

        this.myId = myId;
        this.friendId = friendId;
        sendBox = new JPanel(new FlowLayout());
        sendBox.setPreferredSize(new Dimension(500, 50));
        dialogBox = new JTextArea();
        input = new JTextField(30);
        btn = new JButton("发送");

        // 按钮事件
        btn.addActionListener(this);

        sendBox.add(input);
        sendBox.add(btn);


        this.add(dialogBox);
        this.add(sendBox, "South");
        this.setTitle(myId + "[对话窗口]  " + friendId);
        this.setIconImage((new ImageIcon("image/logo.JPEG")).getImage());
        this.setSize(500,400);
        this.setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btn) {  //发送点击事件
            // 设置要发送的数据
            Message msg = new Message();
            msg.setSender(myId);
            msg.setGetter(friendId);
            msg.setMsg(input.getText());
            System.out.println(msg.toString());
            // 发送数据给服务器
            try {
                outputStream.writeObject(msg);
                outputStream.reset();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            String info = myId + "对"  + friendId + "说：" + input.getText() + "\r\n";
            this.dialogBox.append(info);
            input.setText("");
        }
    }

    @Override
    public void run() {
        // client接收到server消息时的提示方式
        // 该线程用来读取接受的消息
        while(true) {
            try {
                Message msg = (Message)inputStream.readObject();
                // 处理传过来的msg
                if (msg.getCode().equals("2")){
                    JOptionPane.showMessageDialog(null,msg.getMsg());
                }
                else {
                    String info = msg.getSender() + "对"  + msg.getGetter() + "说：" + msg.getMsg() + "\r\n";
                    this.dialogBox.append(info);
                }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }
}
