// 好友列表
package views;

import com.sun.corba.se.impl.ior.FreezableList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class FriendList extends JFrame implements ActionListener, MouseListener {
    private String myName;
    JPanel list;
    JScrollPane scroll;
    Socket socket;
    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;

    public FriendList(String username,Socket socket,ObjectOutputStream outputStream,ObjectInputStream inputStream) {
        this.socket = socket;
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.myName = username;
        list = new JPanel(new GridLayout(50,1,5,4));
        // 列表内容
        JLabel []items = new JLabel[50];
        for(int i=0; i<items.length; i++){
            items[i] = new JLabel(String.valueOf((i + 1)), new ImageIcon("image/icon.JPEG"),JLabel.LEFT);
            items[i].addMouseListener((MouseListener) this);
            list.add(items[i]);
        }
        scroll = new JScrollPane(list);

        this.add(scroll);
        this.setSize(350,500);
        this.setTitle(username + "的好友列表");
        this.setIconImage((new ImageIcon("image/myIcon.JPG")).getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // 双击才响应事件，并获取好友编号
        if(e.getClickCount() == 2) {
            String id = ((JLabel)e.getSource()).getText();
            Chat chat = new Chat(myName,id,socket,inputStream,outputStream);
            Thread t = new Thread(chat);
            t.start();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {
        JLabel item = (JLabel) e.getSource();
        item.setForeground(Color.pink);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        JLabel item = (JLabel) e.getSource();
        item.setForeground(Color.black);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
