/* 响应数据一些格式定义
code:1 -- 登陆成功
code:2 -- 登陆失败
code:3 -- 普通的信息包
 */

package common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Message implements Serializable {
    private String code;

    private String sender;      // 发送者
    private String getter;      // 接收者
    private String msg;     // 信息内容

}

